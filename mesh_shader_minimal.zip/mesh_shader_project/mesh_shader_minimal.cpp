// ============================================================
//  Mesh Shader + Task Shader con Culling Basico
//  Basado en la API real usada por nvpro-samples/gl_vk_meshlet_cadscene
//  (el repo de tu profe), simplificado a 3 meshlets fijos.
//
//  El Task Shader decide cuales de los 3 triangulos (meshlets)
//  sobreviven segun su posicion X vs. un umbral controlable con
//  las flechas del teclado -- el mismo mecanismo de culling a
//  nivel de grupo que usa el repo real, pero con una condicion
//  mucho mas simple (posicion en vez de bounding box + frustum).
//
//  Requiere: una GPU con soporte GL_NV_mesh_shader (Nvidia RTX,
//  Turing en adelante).
//
//  Compilar:
//    g++ -std=c++17 -O2 mesh_shader_minimal.cpp -o mesh_shader_minimal -lglfw -lGLEW -lGL
// ============================================================
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <cstdio>
#include <cstring>
#include <algorithm>

// ============================================================
//  Task Shader: decide QUE meshlets sobreviven (culling), antes
//  de que el Mesh Shader toque un solo vertice de ellos.
// ============================================================
static const char* TASK_SRC = R"(
#version 450
#extension GL_NV_mesh_shader : require

layout(local_size_x = 3) in;

taskNV out Task {
    uint meshletIndices[3];
} OUT;

uniform float cullThreshold;

shared uint survivingCount;

const vec3 meshletCenters[3] = vec3[3](
    vec3(-0.6, 0.0, 0.0),
    vec3( 0.0, 0.0, 0.0),
    vec3( 0.6, 0.0, 0.0)
);

void main() {
    uint idx = gl_LocalInvocationID.x;

    if (idx == 0) survivingCount = 0;
    barrier();

    bool visible = meshletCenters[idx].x <= cullThreshold;
    if (visible) {
        uint slot = atomicAdd(survivingCount, 1);
        OUT.meshletIndices[slot] = idx;
    }
    barrier();

    if (idx == 0) {
        gl_TaskCountNV = survivingCount;
    }
}
)";

// ------------------------------------------------------------
// El mesh shader: reemplaza Vertex Shader + Input Assembler.
// Ahora lee del Task Shader CUAL meshlet le toca dibujar.
// ------------------------------------------------------------
static const char* MESH_SRC = R"(
#version 450
#extension GL_NV_mesh_shader : require

layout(local_size_x = 1) in;
layout(triangles, max_vertices = 3, max_primitives = 1) out;

taskNV in Task {
    uint meshletIndices[3];
} IN;

layout(location = 0) out PerVertexData {
    vec3 color;
} v_out[];

const vec3 meshletCenters[3] = vec3[3](
    vec3(-0.6, 0.0, 0.0),
    vec3( 0.0, 0.0, 0.0),
    vec3( 0.6, 0.0, 0.0)
);
const vec3 meshletColors[3] = vec3[3](
    vec3(0.98, 0.44, 0.40),
    vec3(0.29, 0.87, 0.50),
    vec3(0.51, 0.55, 0.97)
);
const vec3 triOffsets[3] = vec3[3](
    vec3(-0.15, -0.15, 0.0),
    vec3( 0.15, -0.15, 0.0),
    vec3( 0.0,   0.15, 0.0)
);

void main() {
    uint meshletID = IN.meshletIndices[gl_WorkGroupID.x];
    vec3 center = meshletCenters[meshletID];
    vec3 color  = meshletColors[meshletID];

    for (int i = 0; i < 3; i++) {
        gl_MeshVerticesNV[i].gl_Position = vec4(center + triOffsets[i], 1.0);
        v_out[i].color = color;
    }

    gl_PrimitiveIndicesNV[0] = 0;
    gl_PrimitiveIndicesNV[1] = 1;
    gl_PrimitiveIndicesNV[2] = 2;
    gl_PrimitiveCountNV = 1;
}
)";

static const char* FRAG_SRC = R"(
#version 450
layout(location = 0) in PerVertexData {
    vec3 color;
} v_in;

out vec4 FragColor;

void main() {
    FragColor = vec4(v_in.color, 1.0);
}
)";

static GLuint compileShader(GLenum type, const char* src, const char* label) {
    GLuint shader = glCreateShader(type);
    if (shader == 0) {
        GLenum err = glGetError();
        fprintf(stderr, "glCreateShader() fallo para %s (id=0). glGetError=0x%x\n", label, err);
        fprintf(stderr, "Esto significa que el driver ANUNCIA la extension pero no puede\n");
        fprintf(stderr, "crear shaders de ese tipo realmente -- comun en renderizadores\n");
        fprintf(stderr, "de software. Se necesita una GPU Nvidia RTX real.\n");
        return 0;
    }
    glShaderSource(shader, 1, &src, nullptr);
    glCompileShader(shader);
    GLint ok = GL_FALSE;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[2048];
        glGetShaderInfoLog(shader, 2048, nullptr, log);
        fprintf(stderr, "Error compilando %s:\n%s\n", label, log);
        return 0;
    }
    return shader;
}

int main() {
    if (!glfwInit()) { fprintf(stderr, "Error iniciando GLFW\n"); return 1; }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 5);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWwindow* window = glfwCreateWindow(600, 600, "Mesh Shader + Task Shader (Culling)", nullptr, nullptr);
    if (!window) { fprintf(stderr, "Error creando ventana\n"); glfwTerminate(); return 1; }
    glfwMakeContextCurrent(window);

    glewExperimental = GL_TRUE;
    GLenum glewStatus = glewInit();
    if (glewStatus != GLEW_OK) {
        fprintf(stderr, "Error iniciando GLEW: %s\n", glewGetErrorString(glewStatus));
        return 1;
    }

    printf("GPU / Renderer : %s\n", glGetString(GL_RENDERER));
    printf("Version OpenGL : %s\n", glGetString(GL_VERSION));

    // ---- El chequeo mas importante: esta extension disponible aqui? ----
    if (!GLEW_NV_mesh_shader) {
        printf("\n");
        printf("================================================================\n");
        printf(" GL_NV_mesh_shader NO esta disponible en esta GPU/driver.\n");
        printf(" Esto es normal en GPUs de software (Mesa/llvmpipe) o en\n");
        printf(" tarjetas graficas que no son Nvidia Turing (RTX 20xx) o mas\n");
        printf(" nuevas. El codigo esta correcto y compilo bien -- necesita\n");
        printf(" correrse en una maquina con GPU Nvidia RTX real para dibujar\n");
        printf(" el triangulo en pantalla.\n");
        printf("================================================================\n\n");
        glfwTerminate();
        return 0;
    }

    printf("GL_NV_mesh_shader SI esta disponible. Dibujando el triangulo...\n");

    GLuint taskShader = compileShader(GL_TASK_SHADER_NV, TASK_SRC, "task shader");
    GLuint meshShader = compileShader(GL_MESH_SHADER_NV, MESH_SRC, "mesh shader");
    GLuint fragShader = compileShader(GL_FRAGMENT_SHADER, FRAG_SRC, "fragment shader");
    if (!taskShader || !meshShader || !fragShader) return 1;

    GLuint program = glCreateProgram();
    glAttachShader(program, taskShader);
    glAttachShader(program, meshShader);
    glAttachShader(program, fragShader);
    glLinkProgram(program);
    glDeleteShader(taskShader);
    glDeleteShader(meshShader);
    glDeleteShader(fragShader);

    GLint linkOk;
    glGetProgramiv(program, GL_LINK_STATUS, &linkOk);
    if (!linkOk) {
        char log[2048];
        glGetProgramInfoLog(program, 2048, nullptr, log);
        fprintf(stderr, "Error linkeando: %s\n", log);
        return 1;
    }

    glClearColor(0.043f, 0.071f, 0.125f, 1.0f);

    GLint locCullThreshold = glGetUniformLocation(program, "cullThreshold");
    float cullThreshold = 1.0f; // 1.0 = los 3 meshlets pasan (nada se descarta)

    printf("\nControles:\n");
    printf("  FLECHA IZQUIERDA / DERECHA : mover el umbral de culling\n");
    printf("  ESC                        : salir\n\n");

    double lastKeyTime = 0;

    while (!glfwWindowShouldClose(window)) {
        glfwPollEvents();

        double now = glfwGetTime();
        if (now - lastKeyTime > 0.05) { // limitar velocidad de cambio
            if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS) {
                cullThreshold -= 0.02f;
                lastKeyTime = now;
            }
            if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS) {
                cullThreshold += 0.02f;
                lastKeyTime = now;
            }
            cullThreshold = std::max(-1.0f, std::min(1.0f, cullThreshold));
        }

        glClear(GL_COLOR_BUFFER_BIT);

        glUseProgram(program);
        glUniform1f(locCullThreshold, cullThreshold);

        // Lanzamos 1 workgroup de TASK shader (con 3 hilos internos,
        // uno por cada meshlet candidato). El Task Shader decide
        // cuantos workgroups de MESH shader se disparan despues.
        glDrawMeshTasksNV(0, 1);

        glfwSwapBuffers(window);
        if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) break;
    }

    glfwTerminate();
    return 0;
}
