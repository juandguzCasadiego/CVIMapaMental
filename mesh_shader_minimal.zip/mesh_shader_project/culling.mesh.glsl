#version 450
#extension GL_NV_mesh_shader : require

layout(local_size_x = 1) in;
layout(triangles, max_vertices = 3, max_primitives = 1) out;

// Recibe del Task Shader la lista de indices que SI sobrevivieron.
// gl_WorkGroupID.x nos dice "soy el N-esimo meshlet sobreviviente"
// -- no el N-esimo meshlet original.
taskNV in Task {
    uint meshletIndices[3];
} IN;

layout(location = 0) out PerVertexData {
    vec3 color;
} v_out[];

const vec3 meshletCenters[3] = vec3[3](
    vec3(-0.6, 0.0, 0.0),
    vec3( 0.0, 0.0, 0.0),
    vec3( 0.6, 0.0, 0.0)
);
const vec3 meshletColors[3] = vec3[3](
    vec3(0.98, 0.44, 0.40),  // rojo   - meshlet izquierdo
    vec3(0.29, 0.87, 0.50),  // verde  - meshlet central
    vec3(0.51, 0.55, 0.97)   // indigo - meshlet derecho
);
const vec3 triOffsets[3] = vec3[3](
    vec3(-0.15, -0.15, 0.0),
    vec3( 0.15, -0.15, 0.0),
    vec3( 0.0,   0.15, 0.0)
);

void main() {
    // Este workgroup de Mesh Shader SOLO existe porque el Task Shader
    // decidio que este meshlet era visible -- si fue culled, este
    // codigo ni siquiera se ejecuta para el.
    uint meshletID = IN.meshletIndices[gl_WorkGroupID.x];

    vec3 center = meshletCenters[meshletID];
    vec3 color  = meshletColors[meshletID];

    for (int i = 0; i < 3; i++) {
        gl_MeshVerticesNV[i].gl_Position = vec4(center + triOffsets[i], 1.0);
        v_out[i].color = color;
    }

    gl_PrimitiveIndicesNV[0] = 0;
    gl_PrimitiveIndicesNV[1] = 1;
    gl_PrimitiveIndicesNV[2] = 2;
    gl_PrimitiveCountNV = 1;
}
