#version 450
#extension GL_NV_mesh_shader : require

// 3 hilos = 1 hilo por cada meshlet candidato.
// En el repo real de Nvidia esto seria mucho mas grande (uno
// por cada meshlet de un modelo con miles de ellos).
layout(local_size_x = 3) in;

// Datos que le pasamos al Mesh Shader para cada meshlet que
// sobrevive el culling: aqui solo mandamos su indice.
taskNV out Task {
    uint meshletIndices[3];
} OUT;

uniform float cullThreshold; // controlado con las flechas del teclado

shared uint survivingCount;

// Centro (bounding sphere simplificado a un punto) de cada meshlet candidato
const vec3 meshletCenters[3] = vec3[3](
    vec3(-0.6, 0.0, 0.0),
    vec3( 0.0, 0.0, 0.0),
    vec3( 0.6, 0.0, 0.0)
);

void main() {
    uint idx = gl_LocalInvocationID.x;

    if (idx == 0) {
        survivingCount = 0;
    }
    barrier();

    // ---- CULLING: la prueba mas simple posible ----
    // Si el centro del meshlet esta a la derecha del umbral, se descarta
    // ENTERO -- ni un solo vertice de ese meshlet llega al Mesh Shader.
    bool visible = meshletCenters[idx].x <= cullThreshold;

    if (visible) {
        uint slot = atomicAdd(survivingCount, 1);
        OUT.meshletIndices[slot] = idx;
    }
    barrier();

    // El hilo 0 reporta cuantos meshlets sobrevivieron: eso le dice a la
    // GPU cuantos workgroups de Mesh Shader debe lanzar despues.
    if (idx == 0) {
        gl_TaskCountNV = survivingCount;
    }
}
