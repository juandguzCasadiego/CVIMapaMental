# Mesh Shader + Task Shader con Culling Básico

Versión simplificada de
[gl_vk_meshlet_cadscene](https://github.com/juandguzCasadiego/gl_vk_meshlet_cadscene)
(fork del sample oficial de Nvidia, `nvpro-samples/gl_vk_meshlet_cadscene`),
ahora con **2 etapas**: Task Shader (culling) → Mesh Shader (generación de
geometría) — el flujo completo que reemplaza Vertex Processing + Clipping
en el pipeline clásico.

## Qué hace este programa

Hay **3 meshlets candidatos** — 3 triángulos en posiciones fijas (izquierda,
centro, derecha). Cada frame:

1. **Task Shader** (`culling.task.glsl`): lanza 3 hilos, uno por meshlet.
   Cada hilo compara la posición X de su meshlet contra un umbral
   (`cullThreshold`, controlado con las flechas del teclado). Si el
   meshlet queda a la derecha del umbral, se descarta **por completo** —
   ni un solo vértice de ese meshlet llega a la siguiente etapa.
2. **Mesh Shader** (`culling.mesh.glsl`): solo se ejecuta para los
   meshlets que sobrevivieron. Cada workgroup de Mesh Shader genera los
   3 vértices y el triángulo de su meshlet asignado.

Mueve el umbral con las flechas del teclado y verás los triángulos
aparecer y desaparecer en grupo — la prueba visual de que el culling pasa
**antes** de generar cualquier geometría, no después.

## Qué se quitó del repo original (y por qué)

| Se quita | Se queda |
|---|---|
| Buffers de meshlets pre-calculados (`GEOMETRY_SSBO_MESHLETDESC`) | 3 meshlets escritos a mano, directo en los shaders |
| Culling por bounding box + view frustum real | Culling por posición X vs. un umbral simple |
| Soporte Vulkan + OpenGL | Solo OpenGL (más simple de compilar) |
| Framework `nvpro-samples` completo | Solo GLFW + GLEW |
| Miles de meshlets, modelos CAD reales | 3 triángulos = 3 "meshlets" |

## Mapeo con el repo real

| Archivo del repo real | Qué hace | Equivalente aquí |
|---|---|---|
| `drawmeshlet_nv.task.glsl` | Task shader: decide qué meshlets sobreviven usando bounding boxes reales | `culling.task.glsl` — decide con una comparación de posición X |
| `drawmeshlet_nv_basic.mesh.glsl` | Mesh shader: genera vértices/triángulos de un meshlet desde buffers | `culling.mesh.glsl` — genera un triángulo fijo por meshlet |
| `gl_TaskCountNV` | Le dice a la GPU cuántos workgroups de Mesh Shader lanzar | Igual aquí — literalmente la misma variable del lenguaje |
| `common.h` (bindings de buffers) | No aplica — no tenemos buffers, todo hardcodeado |

## Cómo correrlo

**Importante**: necesita una GPU Nvidia real, Turing (RTX 20xx) o más
nueva. En GPUs sin soporte real (como el renderer de software de este
sandbox de pruebas), el programa lo detecta y te avisa en vez de fallar
en silencio.

```bash
sudo apt install libglfw3-dev libglew-dev libgl1-mesa-dev
g++ -std=c++17 -O2 mesh_shader_minimal.cpp -o mesh_shader_minimal -lglfw -lGLEW -lGL
./mesh_shader_minimal
```

**Controles**: flecha izquierda/derecha mueve el umbral de culling, ESC
para salir.

## Verificado en este entorno (sin GPU Nvidia)

Los shaders (`culling.task.glsl` y `culling.mesh.glsl`) se validaron de
forma **independiente del hardware** con `glslangValidator` — la
herramienta oficial de Khronos — confirmando que la sintaxis GLSL es
correcta para las etapas `task` y `mesh`:

```
$ glslangValidator -S task culling.task.glsl
(sin errores)
$ glslangValidator -S mesh culling.mesh.glsl
(sin errores)
```

El programa compilado corre y detecta correctamente la falta de soporte
real en este hardware:

```
GPU / Renderer : llvmpipe (LLVM 20.1.2, 256 bits)
Version OpenGL : 4.5 (Core Profile) Mesa 25.2.8

GL_NV_mesh_shader SI esta disponible.
glCreateShader() fallo para task shader (id=0). glGetError=0x500
glCreateShader() fallo para mesh shader (id=0). glGetError=0x500
```

(Mesa anuncia el nombre de la extensión pero no implementa de verdad la
creación de shaders de este tipo en su renderizador de software — por
eso ambos fallan igual, de forma consistente.)

## Siguiente paso para tu proyecto

Para acercarte aún más al repo real:

1. Subir de 3 a, digamos, 27 meshlets en una grilla — verás el culling
   descartando muchos más triángulos de una vez.
2. Agregar una segunda condición de culling (por ejemplo backface
   culling, comparando la orientación del triángulo contra la cámara).
3. Reemplazar los meshlets hardcodeados por datos leídos de un buffer
   (`buffer` en vez de `const`), como hace `drawmeshlet_nv_basic.mesh.glsl`
   en el repo original — el paso final antes de trabajar con modelos 3D
   reales en vez de triángulos fijos.

